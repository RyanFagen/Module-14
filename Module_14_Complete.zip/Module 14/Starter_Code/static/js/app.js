// Build the metadata panel
function buildMetadata(sample) {
  d3.json("https://static.bc-edx.com/data/dl-1-2/m14/lms/starter/samples.json").then((data) => {

    // get the metadata field
    // Is this right, or am I doing it wrong? None of the in-class examples gave me
    // what I'm looking for, and there's no indication of whether d3 is required,
    // not allowed, or neither. This is the best I could find online:
    // source: https://www.dotcms.com/docs/latest/json-field
    let metaField = data.metadata

    // Filter the metadata for the object with the desired sample number
    let metaFilter = metaField.filter(sampleId => sampleId.id == sample);

    // Use d3 to select the panel with id of `#sample-metadata`
    // Use `.html("") to clear any existing metadata
    // Why were these seperate before?
    let sampleData = d3.select("#sample-metadata").html();

    // Inside a loop, you will need to use d3 to append new
    // tags for each key-value in the filtered metadata.
    // This is the closest I could come up with based on the in-class examples, but
    // I'm still not sure whether or not this is the correct syntax because the
    // in-class examples weren't very useful.
    for (let i = 0; i < metaFilter.length; i++) {
      sampleData.append(metaFilter[i]);
    };

  });
}

// function to build both charts
function buildCharts(sample) {
  d3.json("https://static.bc-edx.com/data/dl-1-2/m14/lms/starter/samples.json").then((data) => {

    // Get the samples field
    let sampleField = data.samples;

    // Filter the samples for the object with the desired sample number
    let sampleFilter = sampleField.filter(sampleId => sampleId.id == sample);

    // Get the otu_ids, otu_labels, and sample_values
    // How does the sample filter tie into all of this? Are we supposed to use 
    // jsonField again, or do we use sampleFilter instead, and if so, is this the
    // correct spot to use it at?
    let otu_ids = sample_filter.otu_ids;
    let otu_labels = sample_filter.otu_labels;
    let sample_values = sampleFilter.sample_values;

    // Build a Bubble Chart
    // The in-class examples only showed us how to make bar charts.
    let trace1 = {
      x: otu_ids,
      y: sample_values,
      text: otu_labels,
      type: "bubble"
    };

    // Render the Bubble Chart
    let data = [trace1];
    Plotly.newPlot("plot", data);

    // For the Bar Chart, map the otu_ids to a list of strings for your yticks
    // Build a Bar Chart
    // Don't forget to slice and reverse the input data appropriately
    // Again, why were these seperate before? Also, what variables do I use for the
    // slice and map methods?
    let sliced_ids = otu_ids.slice(0, sample);
    sliced_ids.reverse();
    let trace2 = {
      x: sliced_ids.map(object => object.otu_ids),
      y: sample_values,
      text: otu_labels,
      type: "bar"
    };
    let data = [trace2];
    // Render the Bar Chart
    Plotly.newPlot("plot", data);
  });
}

// Function to run on page load
function init() {
  d3.json("https://static.bc-edx.com/data/dl-1-2/m14/lms/starter/samples.json").then((data) => {

    // Get the names field
    let namesField = data.names;

    // Use d3 to select the dropdown with id of `#selDataset`
    let selectedData = d3.select("#selDataset");

    // Use the list of sample names to populate the select options
    // Hint: Inside a loop, you will need to use d3 to append a new
    // option for each sample name.
    for (let i = 0; i < namesField.length; i++) {
      selectedData.append(namesField[i]);

    // Get the first sample from the list
    let sample = namesField[0];

    // Build charts and metadata panel with the first sample
    buildMetadata(sample);
    buildCharts(sample);
  });
}

// Function for event listener
// Where do we call this method?
function optionChanged(newSample) {
  // Build charts and metadata panel each time a new sample is selected
  buildMetadata(newSample);
  buildCharts(newSample);
}

// Initialize the dashboard
init();
